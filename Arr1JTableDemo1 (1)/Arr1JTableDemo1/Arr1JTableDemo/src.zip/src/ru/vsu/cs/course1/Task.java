package ru.vsu.cs.course1;


import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Task {



    public static int[] elMaS(int[] arr, int n) {

        ArrayList<Integer> listNew = new ArrayList<>();
        for(Integer el: arr){
            listNew.add(el);
        }
        return process(listNew, n);
    }


    public static int[] process(ArrayList<Integer> list, int n) {
        ArrayList<Integer> listNew = new ArrayList<>();

        Collections.sort(list);

        for (int num : list) {
            if (listNew.contains(num)) {
                continue;
            }

            listNew.add(num);

            if (listNew.size() == n) {
                break;
            }
        }

        return toMas1(listNew);
    }
    public static int[] toMas1(ArrayList<Integer> list) {
        Integer[] arr = list.toArray(new Integer[0]);
        int[] result = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            result[i] = arr[i];
        }
        return result;
    }

}



